/*
 * Rufs - Remote Union File System
 *
 * Copyright 2017 Matthias Ladkau. All rights reserved.
 *
 * This Source Code Form is subject to the terms of the MIT
 * License, If a copy of the MIT License was not distributed with this
 * file, You can obtain one at https://opensource.org/licenses/MIT.
 */

var rufs;
if (rufs === undefined) {
    rufs = {};
}

rufs.util = {

    // Path for API calls

    API_PATH : "/fs/v1",

    api_call_lock : {},

    // Construct a file url
    //
    fileURL : function (tree, path) {
        "use strict";

        return rufs.util.API_PATH + "/file/" + tree + "/" + path;
    },

    // Do an API call to the backend.
    //
    // endpoint       - REST endpoint to call.
    // method         - HTTP method to use (e.g. POST)
    // params         - Parameter for the action - ignored for GET requests.
    // callback       - Callback to call after the request returns.
    //                  Parameter is: response
    // error_callback - Optional: Error callback if the request return an error.
    //                            Parameters: code, response, exception
    //
    api : function (endpoint, method, params, callback, error_callback) {
        "use strict";

        // Prevent multiple calls to the same endpoint

        if (rufs.util.api_call_lock[endpoint]) {
            return;
        }

        var http = new XMLHttpRequest();

        // Send an async ajax call

        http.open(method, rufs.util.API_PATH + "/" + endpoint, true);
        http.setRequestHeader("content-type", "application/json");

        rufs.util.api_call_lock[endpoint] = true;

        http.onload = function () {

            delete rufs.util.api_call_lock[endpoint];

            try {
                if (http.status === 200) {
                    var response
                    if (http.response) {
                        response = JSON.parse(http.response);
                    }
                    if (callback) {
                        callback(response, http);
                    }
                } else {
                    var err;
                    try {
                        err  = JSON.parse(http.response)["error"];
                    } catch(e) {
                        err = http.response.trim();
                    }
                    console.log("API call failed - response: ", err);
                    if (error_callback !== undefined) {
                        error_callback(http.status, err);
                    }
                }
            } catch(e) {
                console.log("API call failed - exception:", e);
                if (error_callback !== undefined) {
                    error_callback(undefined, undefined, e);
                }
            }
        };

        if (method.toLowerCase() === "get") {
            http.send();
        } else {
            http.send(JSON.stringify(params));
        }
    },

    // Escape HTML function
    //
    esc : function (unsafe) {
        if (unsafe) {
            return unsafe
                 .replace(/&/g, "&amp;")
                 .replace(/</g, "&lt;")
                 .replace(/>/g, "&gt;")
                 .replace(/"/g, "&quot;")
                 .replace(/'/g, "&#039;");
        }
    },

    // Merge two objects.
    //
    // o1 - Object to merge from.
    // o2 - Object to merge into (already existing
    //      attributes will not be overwritten).
    //
    // Returns o2.
    //
    mergeObjects : function (o1, o2) {
        "use strict";
        for (var attr in o1) {
            if(o2[attr] === undefined) {
                o2[attr] = o1[attr];
            }
        }

        return o2;
    },

    // Iterate over a list.
    //
    // list - List to iterate over.
    // iterator - Function to be called in each step - gets
    //            the index and element as parameter. If the
    //            function returns false then the iteration
    //            ends immediately.
    //
    iter : function (list, iterator) {
        "use strict";
        for (var i=0;i<list.length;i++) {
            if (iterator(i, list[i]) === false) {
                break;
            }
        }
    },

    // Get a list of keys on an object.
    // This will ignore "inherited" keys.
    //
    oKeys : function (obj) {
        "use strict";
        var key, keys = [];
        for(key in obj) {
            if (obj.hasOwnProperty(key)) {
                keys.push(key);
            }
        }
        return keys;
    },

    // Convert values of an object into booleans.
    //
    oValBool : function (obj, keys) {
        "use strict";

        for (var i=0;i<keys.length;i++) {
            var k = keys[i];
            if (obj[k] !== undefined) {
                var val = String(obj[k]).toLowerCase();
                obj[k] =  val == "true" || val == "1";
            }
        }
    },

    // Add an event handler to an element. This function makes sure
    // that an event listener is not added twice.
    //
    // element   - Element to which the event handler should be attached.
    // eventName - Name of the event.
    // func      - Event handler.
    //
    observe : function (element, eventName, func) {
        "use strict";

        var handlers = rufs.util.getData(element)["_event_handlers"];

        handlers = handlers === undefined ? {} : handlers;

        if (handlers !== undefined && handlers[func]) {

            // Handler was already added no need to add it twice

            return;
        }

        handlers[func] = true;
        rufs.util.storeData(element, { "_event_handlers" : handlers});

        // Add the event listener

        if (element.addEventListener) {
            element.addEventListener(eventName, func, false);
        } else if (element.attachEvent) {
            element.attachEvent('on' + eventName, func);
        }
    },

    // Dom traversal
    // =============

    // Element lookup.
    //
    // id - Element ID to lookup.
    //
    // Returns the element.
    //
    $ : function(id) {
        "use strict";
        return document.getElementById(id);
    },

    // Search a child element which has a certain class name.
    //
    // element   - Root element.
    // classname - Class name to search.
    //
    // Returns the first found child or undefined.
    //
    find : function (element, classname) {
        var s = function (r) {

            if (!r) {
                return undefined;
            }

            if (rufs.util.hasClassName(r, classname)) {
                return r
            }

			if (r.childNodes) {
				for (var i=0; i < r.childNodes.length; i++) {
					var cn = s(r.childNodes[i]);
					if (cn !== undefined) {
						return cn;
					}
				}
			}
        };

        return s(element);
    },

    // Search all child elements which have a certain class name.
    //
    // element   - Root element.
    // classname - Class name to search.
    //
    // Returns all found children.
    //
    findAll : function (element, classname) {
        var ret = [],
            s = function (r) {
                if (rufs.util.hasClassName(r, classname)) {
                    ret.push(r);
                }
                for (var i=0; i < r.childNodes.length; i++) {
                    s(r.childNodes[i]);
                }
            };

        s(element);

        return ret;
    },

    // Search a parent element which has a certain class name.
    //
    // element   - Child element.
    // classname - Class name to search.
    //
    // Returns the first found parent or undefined.
    //
    findParent : function (element, classname) {
        "use strict";

        var s = function (r) {

            if (!r) {
                return undefined;
            }

            if (rufs.util.hasClassName(r, classname)) {
                return r;
            }

            return s(r.parentNode);
        };

        return s(element);
    },

    // Get the next sibling of a dom element.
    //
    next : function (element) {
        "use strict";

        return element.nextSibling;
    },

    // Get the previous sibling of a dom element.
    //
    prev : function (element) {
        "use strict";

        return element.previousSibling;
    },

    // Get all further sibling of a dom element.
    //
    nextAll : function (element) {
        "use strict";

        var ret = [];

        while(element = rufs.util.next(element)) {
            ret.push(element);
        }

        return ret;
    },

    // Dom manipulation
    // ================

    // Create a dom element.
    //
    // tag   - Element name (e.g. "a").
    // attrs - Element attributes (e.g. "href")
    //
    create : function(tag, attrs) {
        "use strict";
        var element = document.createElement(tag);
        if (attrs !== undefined) {
            rufs.util.iter(rufs.util.oKeys(attrs), function (i, v) {
                element.setAttribute(v, attrs[v]);
            });
        }
        return element;
    },

    // Replace an existing dom element.
    //
    // element    - Element to replace.
    // newelement - New element.
    //
    // Returns the replaced element.
    //
	replace : function (element, newelement) {
		return element.parentNode.replaceChild(newelement, element)
	},

    // Create a new text node.
    //
    // text - text to insert into text node.
    //
    createText : function(text) {
        "use strict";

        return document.createTextNode(text);
    },

	// Remove an element from the dom.
	//
    // element - Element to remove.
    //
    // Returns the removed element.
    //
	remove : function (element) {
		"use strict";

		return element.parentNode.removeChild(element);
	},

    // Insert a dom element as a child element of another dom element.
    //
    // element - Existing parent element.
    // child   - Element to add as a child.
    //
    insert : function(element, child) {
        "use strict";
        element.appendChild(child);
        return element;
    },

    // Insert all dom elements as children of another dom element.
    //
    // element  - Existing parent element.
    // children - Elements to add as children.
    //
    insertAll : function(element, children) {
        "use strict";
        rufs.util.iter(children, function (i, item) {
            if (item !== undefined) {
                element.appendChild(item);
            }
        });
        return element;
    },

    // Insert a dom element before another dom element.
    //
    // element - Existing dom element.
    // child   - Element to insert.
    //
    insertBefore : function(element, child) {
        "use strict";
        element.parentNode.insertBefore(child, element);
    },

    // Insert a dom element after another dom element.
    //
    // element - Existing dom element.
    // child   - Element to insert.
    //
    insertAfter : function(element, child) {
        "use strict";
        element.parentNode.insertBefore(child, element.nextSibling);
    },

    // Class Names
    // ===========

    // Ensure that a given element has a certain class name.
    //
    // element - Existing dom element.
    // name    - Class name.
    //
    // Returns the given element.
    //
    ensureClassName : function(element, name) {
        "use strict";
        if (rufs.util.hasClassName(element, name)) {
            return;
        }
        var classes = element.getAttribute("class");
        if (classes === null || classes.length === 0) {
            classes = name;
        } else {
            classes += " " + name;
        }
        element.setAttribute("class", classes);

        return element;
    },

    // Check if a given element has a class name.
    //
    // element - Existing dom element.
    // name    - Class name to check.
    //
    // Return true if the element has the class name - false otherwise.
    //
    hasClassName : function(element, name) {
        "use strict";
        if (element.getAttribute === undefined) {
            return false;
        }
        var classes = element.getAttribute("class");
        if (classes === null) {
            return false;
        }
        return classes.split(" ").indexOf(name) !== -1;
    },

    // Remove a class name from a given element.
    //
    // element - Existing dom element.
    // name    - Class name to remove.
    //
    // Returns the given element.
    //
    removeClassName : function(element, name) {
        "use strict";

        if (element !== undefined) {
            var classes = element.getAttribute("class").split(" "),
                index   = classes.indexOf(name);
            if (index !== -1) {
                classes.splice(index, 1);
                element.setAttribute("class", classes.join(" "));
            }
        }

        return element;
    },

    // Show / hide elements
    // ====================

    // Hide an element
    //
    // element - Element to hide.
    //
    hide : function(element) {
        element.style.display = 'none';
    },

    // Hide elements
    //
    // elements - List of elements to hide.
    //
    hideAll : function(elements) {
        rufs.util.iter(elements, function (i, item) { rufs.util.hide(item); });
    },

    // Show an element
    //
    // element - Element to show.
    //
    show : function(element) {
        element.style.display = '';
    },

    // Show elements
    //
    // elements - List of elements to show.
    //
    showAll : function(elements) {
        crufs.utilf.iter(elements, function (i, item) { rufs.util.show(item); });
    },

    // Data storage on DOM elements
    // ============================

    DOM_STORE_ATTR : "_rufsdata", // Attribute name on dom elements
                                  // which hold data

    storeData : function (element, data) {
        "use strict";
        var edata = element[rufs.util.DOM_STORE_ATTR];

        if (edata === undefined) {
            edata = {};
        }

        element[rufs.util.DOM_STORE_ATTR] = rufs.util.mergeObjects(data, edata);

        return element;
    },

    getData : function (element) {
        "use strict";
        var ret;

        try {
            ret = element[rufs.util.DOM_STORE_ATTR];
        } catch (e) {
        }

        return ret !== undefined ? ret : {};
    }
};

// Tabbing support
// ===============

rufs.tabbing = {

    tabbingListener : [],

    // Initialise a tabbing area
    //
    init : function (element, config) {
        rufs.tabbing._create(rufs.util.find(element, "rufs-tabbed-area-tabs"),
            function (index, tab) {
                rufs.util.iter(rufs.tabbing.tabbingListener, function (i, v) {
                    v(index, tab);
                });
            }, config);
    },

    // Add tabbing logic to a tabbing area.
    //
    _create : function (element, callback, config) {
        "use strict";
        var tabs = rufs.util.findAll(element, 'rufs-tabbed-area-tab'),
            content = rufs.util.findAll(element, 'rufs-tabbed-area-tab-content');

        // Hide all tabs but one

        rufs.util.hideAll(content);

        rufs.util.show(content[config.initial_tab]);
        rufs.util.ensureClassName(tabs[config.initial_tab], "selected");

        // Bind action handler to each tab

        rufs.util.iter(tabs, function (i, v) {
            var selectTab = function () {
                rufs.util.iter(tabs, function (i, item) { rufs.util.removeClassName(item, "selected"); });
                rufs.util.ensureClassName(tabs[i], "selected");
                rufs.util.hideAll(content);
                rufs.util.show(content[i]);

                if (callback !== undefined) {
                    callback(i, tabs[i]);
                }
            };
            rufs.util.observe(v, "click", selectTab);
            v.selectTab = selectTab;
        });
    }
};

// URL parameters
// ==============

// Return all URL query parameters
//
rufs.getURLParams = function() {
    "use strict";
    var qs = document.location.search.split('+').join(' '),
        params = {},
        tokens,
        re = /[?&]?([^=]+)=([^&]*)/g;

    while (tokens = re.exec(qs)) {
        params[decodeURIComponent(tokens[1])] = decodeURIComponent(tokens[2]);
    }

    return params;
}

// Set a URL parameter without refreshing the page.
//
rufs.setURLParam = function(paramName, paramValue) {
    "use strict";
    var url = window.location.href;

    if (url.indexOf(paramName + "=") >= 0) {
        var prefix = url.substring(0, url.indexOf(paramName)),
            suffix = url.substring(url.indexOf(paramName));

        suffix = suffix.substring(suffix.indexOf("=") + 1);
        suffix = (suffix.indexOf("&") >= 0) ? suffix.substring(suffix.indexOf("&"))
                                            : "";

        url = prefix + paramName + "=" + paramValue + suffix;

    } else {

        if (url.indexOf("?") < 0) {
            url += "?" + paramName + "=" + paramValue;
        } else {
            url += "&" + paramName + "=" + paramValue;
        }
    }

    window.history.pushState(null, null, url);
}

// Remove URL parameter without refreshing the page.
//
rufs.removeURLParam = function (paramName) {
    "use strict";
    var url = window.location.href,
        urlparts= url.split('?');

    if (urlparts.length >= 2) {

        var prefix= paramName + '=',
            pars = urlparts[1].split(/[&;]/g);

        for (var i = pars.length - 1; i >= 0; i--) {
            if (pars[i].lastIndexOf(prefix, 0) !== -1) {
                pars.splice(i, 1);
            }
        }

        url = urlparts[0] + (pars.length > 0 ? '?' + pars.join('&') : "");

        window.history.pushState(null, null, url);
    }
}

/*
ByteSizeString takes a numeric byte size and returns it in human readable form.
The useISU parameter determines which units to use. False uses the more common
binary form. The units kibibyte, mebibyte, etc were established by the
International Electrotechnical Commission (IEC) in 1998.

useISU = True -> Decimal (as formally defined in the International System of Units)
Bytes / Metric
1000^1 kB kilobyte
1000^2 MB megabyte
1000^3 GB gigabyte
1000^4 TB terabyte
1000^5 PB petabyte
1000^6 EB exabyte

useISU = False -> Binary (as defined by the International Electrotechnical Commission)
Bytes / Metric
1024^1 KiB kibibyte
1024^2 MiB mebibyte
1024^3 GiB gibibyte
1024^4 TiB tebibyte
1024^5 PiB pebibyte
1024^6 EiB exbibyte
*/
rufs.byteSizeString = function (size, useISU) {
    "use strict";

    var unit = 1024,
        exp,
        pre,
        res;

    if (useISU) {
        unit = 1000;
    }

    if (size < unit) {
        return size + " B";
    }

    exp = Math.floor(Math.log(size) / Math.log(unit))

    if (useISU) {
        pre = "kMGTPE"[exp-1]
    } else {
        pre = "KMGTPE"[exp-1] + "i"
    }

     res = size / Math.pow(unit, exp);

     return res.toFixed(2) + " " + pre + "B";
};


// Drag'n'Drop File Upload
// =======================
//
// Handles file uploads to Rufs.
//
// Example:
//
// HTML: <div id="upload" data-upload-path="/backup"></div>
//
// JS: ddfu.addEvents(document.getElementById("upload"));
//
// Files dropped into the element will be uploaded to:
//
// rufs.ddfu.upload_url + <value of data-upload-path>
//

rufs.ddfu = {

    upload_url : "/fs/v1/file/",

    // Quick check if the browser supports file upload.
    //
    // Returns true if the browser supports file uploads.
    //
    browserSupportsFileUpload : function () {
        "use strict";

        return window.FormData !== undefined;
    },

    callbacks : {

        // Called before starting the upload to the server.
        // Overwrite this function to augement the formData
        // which is send to the server.
        //
        buildFormData : function (element, formData) {
            "use strict";

            element._rufs_browser.showSpinner();
        },

        // Called during the file upload to show progress. Parameter
        // will show completion between 0 - 100 %.
        //
        update : function (element, percent) {
            "use strict";

            percent = Math.round(percent);

            console.log("Uploading ... ", percent, "%")
            element._rufs_browser.showSpinnerText(percent+"%");
        },

        // Called if an error occured.
        //
        error : function(element, status, error_string, ex) {
            "use strict";

            element._rufs_browser.hideAllSpinner();
            element._rufs_browser.refresh();
        },

        success : function (element, response) {
            "use strict";

            element._rufs_browser.hideAllSpinner();
            element._rufs_browser.refresh();
        }
    },

    // Attach drag and drop events to an element and to the document.
    //
    // element : Element to attach events to.
    //
    addEvents : function(element) {
        "use strict";

        var stopEvents = function (e) {
                if (e) {
                    e.stopPropagation();
                    e.preventDefault();
                }
            };

        rufs.ddfu.observe(element, "dragenter", function (e) {
            stopEvents(e);

            if (e.dataTransfer &&
                e.dataTransfer.types &&
                e.dataTransfer.types.indexOf("Files") !== -1) {

                rufs.ddfu.ensureClassName(element, "highlight");
            }
        });

        rufs.ddfu.observe(element, "dragover", stopEvents);

        rufs.ddfu.observe(element, "drop", function (e) {
            stopEvents(e);

            if (rufs.ddfu.hasClassName(element, "highlight") &&
                e.dataTransfer &&
                e.dataTransfer.files.length !== 0) {

                rufs.ddfu.removeClassName(element, "highlight");

                rufs.ddfu.handleFileUpload(e.dataTransfer.files, element);
            }
        });

        rufs.ddfu.observe(element, "dragexit", function (e) {
            stopEvents(e);
            rufs.ddfu.removeClassName(element, "highlight");
        });
    },

    // Handle ajax based file upload.
    //
    // files   - Files to send.
    // element - Element which received the files.
    //
    handleFileUpload : function (files, element) {
        "use strict";

        // Build up form data

        var formData = new FormData();

        rufs.ddfu.callbacks.buildFormData(element, formData);

        var i = 0;
        for (i = 0; i < files.length; i++) {

            formData.append('uploadfile', files[i]);

            // Could do some further processing
            // with files[i].name, files[i].size
        }

        if (i === 0) {

            // Check if there are any files to upload

            common.page_message.addPageMessage("error", "File upload", "No file data to upload");
            return;
        }

        // Construct the upload path and start the upload

        var upload_url = rufs.ddfu.upload_url + element._rufs_config.tree,
            subpath = element.getAttribute("data-upload-path");

        if (subpath) {
            upload_url += subpath;
        }

        rufs.ddfu.api(element, upload_url, "POST", formData,
                 rufs.ddfu.callbacks.success,
                 rufs.ddfu.callbacks.error);
    },

    // Util functions
    // ==============

    // Add an event handler to an element.
    //
    // element   - Element to which the event handler should be attached.
    // eventName - Name of the event.
    // func      - Event handler.
    //
    observe : function (element, eventName, func) {
        "use strict";

        // Add the event listener

        if (element.addEventListener) {
            element.addEventListener(eventName, func, false);
        } else if (element.attachEvent) {
            element.attachEvent('on' + eventName, func);
        }
    },

    // Path for API calls

    api_call_lock : {},

    // Do an API call to the backend.
    //
    // element        - DOM element which initiates the upload.
    // endpoint       - REST endpoint to call.
    // method         - HTTP method to use (e.g. POST)
    // params         - Parameter for the action - ignored for GET requests.
    // callback       - Callback to call after the request returns.
    //                  Parameter is: response
    // error_callback - Optional: Error callback if the request return an error.
    //                            Parameters: code, response, exception
    //
    api : function (element, endpoint, method, params, callback, error_callback) {
        "use strict";

        // Prevent multiple calls to the same endpoint

        if (rufs.ddfu.api_call_lock[endpoint]) {
            return;
        }

        var http = new XMLHttpRequest();

        // Attach upload listener

        rufs.util.observe(http.upload, "progress", function (e) {
            rufs.ddfu.callbacks.update(element, e.loaded / e.total * 100);
        });

        // Send an async ajax call

        http.open(method, endpoint, true);

        if (!params instanceof FormData) {
            http.setRequestHeader("content-type", "application/json");
        }

        rufs.ddfu.api_call_lock[endpoint] = true;

        http.onload = function () {

            delete rufs.ddfu.api_call_lock[endpoint];

            try {
                if (http.status === 200) {
                    var response
                    if (http.response) {
                        response = JSON.parse(http.response);
                    }
                    if (callback) {
                        callback(element, response, http);
                    }
                } else {
                    var err;
                    try {
                        err  = JSON.parse(http.response)["error"];
                    } catch(e) {
                        err = http.response.trim();
                    }
                    console.log("API call failed - response: ", err);
                    if (error_callback !== undefined) {
                        error_callback(element, http.status, err);
                    }
                }
            } catch(e) {
                console.log("API call failed - exception:", e);
                if (error_callback !== undefined) {
                    error_callback(element, undefined, undefined, e);
                }
            }
        };

        if (method.toLowerCase() === "get") {
            http.send();
        } else if (params instanceof FormData) {
            http.send(params);
        } else {
            http.send(JSON.stringify(params));
        }
    },

    // Ensure that a given element has a certain class name.
    //
    // element - Existing dom element.
    // name    - Class name.
    //
    // Returns the given element.
    //
    ensureClassName : function(element, name) {
        "use strict";

        if (rufs.ddfu.hasClassName(element, name)) {
            return;
        }
        var classes = element.getAttribute("class");
        if (classes === null || classes.length === 0) {
            classes = name;
        } else {
            classes += " " + name;
        }
        element.setAttribute("class", classes);

        return element;
    },

    // Check if a given element has a class name.
    //
    // element - Existing dom element.
    // name    - Class name to check.
    //
    // Return true if the element has the class name - false otherwise.
    //
    hasClassName : function(element, name) {
        "use strict";
        if (element.getAttribute === undefined) {
            return false;
        }
        var classes = element.getAttribute("class");
        if (classes === null) {
            return false;
        }
        return classes.split(" ").indexOf(name) !== -1;
    },

    // Remove a class name from a given element.
    //
    // element - Existing dom element.
    // name    - Class name to remove.
    //
    // Returns the given element.
    //
    removeClassName : function(element, name) {
        "use strict";

        if (element !== undefined) {
            var attr = element.getAttribute("class");

            if (attr) {

                var classes = attr.split(" "),
                    index   = classes.indexOf(name);

                if (index !== -1) {
                    classes.splice(index, 1);
                    element.setAttribute("class", classes.join(" "));
                }
            }
        }

        return element;
    }
};

// Class implementation
// ====================
// Class objects with constructor and multi-inheritance support
//
// Based on: Simple JavaScript Inheritance by John Resig
// http://ejohn.org/blog/simple-javascript-inheritance/
//
// Inspired by base2 and Prototype
//

rufs.Class = function () {};
(function () {

    // Pattern which checks if a given function uses the function _super - this test
    // returns always true if toString on a function does not return the function code
    var functionUsesSuper = /abc/.test(function () { abc(); }) ? /\b_super\b/ : /.*/;

    // Flag which is used to detect if we are currently initialising
    var initializing = false;

    // Add create function to the new class object
    rufs.Class.create = function () {

        // Get the current prototype as the super prototype of the new class
        var _super = this.prototype;

        // Clone the current class object (without running the init constructor function)
        initializing = true;
        var prototype = new this();
        initializing = false;

        // Go through all given mixin objects. Each object should be either
        // a normal properties object or a constructor function.
        for (var i = 0; i < arguments.length; i++) {
            var properties = arguments[i];

            // Check if the given mixin is a constructor funtion
            if (typeof properties === "function") {
                // Use the prototype as properties
                properties = properties.prototype;
            }

            // Copy the given properties to the cloned class object
            for (var name in properties) {

                // Check if we're overwriting an existing function and if the new function uses
                // it by calling _super
                if (typeof properties[name] == "function"
                    && typeof _super[name] == "function"
                    && functionUsesSuper.test(properties[name])) {

                // If _super is called we need to wrap the given function
                // in a closure and provide the right environment
                prototype[name] = (
                    function(name, func, _super) {
                        return function() {
                            var t, ret;
                            // Save the current value in _super
                            t = this._super;
                            // Add the function from the current class object as _super function
                            this._super = _super[name];
                            // Run the function which calls _super
                            ret = func.apply(this, arguments);
                            // Restore the old value in _super
                            this._super = t;
                            // Return the result
                            return ret;
                        };
                    }
                )(name, properties[name], _super);

                } else {

                    prototype[name] = properties[name];
                }
            }

            // Once the mixin is added it becomes the new super class
            // so we can have this._super call chains
            _super = properties;
        }

        // Defining a constructor function which is used to call the constructor function init on objects
        var Class = function () {
          if ( !initializing && this.init ) {
            this.init.apply(this, arguments);
          }
        }

        // Put our constructed prototype object in place
        Class.prototype = prototype;

        // Constructor of the new object should be Class
        // (this must be done AFTER the prototype was assigned)
        Class.prototype.constructor = Class;

        // The current function becomes the create function
        // on the new object
        Class.create = arguments.callee;

        return Class;
    };
})();

/*
 * Rufs - Remote Union File System
 *
 * Copyright 2017 Matthias Ladkau. All rights reserved.
 *
 * This Source Code Form is subject to the terms of the MIT
 * License, If a copy of the MIT License was not distributed with this
 * file, You can obtain one at https://opensource.org/licenses/MIT.
 */

var rufs;
if (rufs === undefined) {
    rufs = {};
}

// Main entry point to create a Rufs browser instance
//
rufs.browser = {

    DEFAULT_CONFIG : {
        tree          : "default", // Tree which should be displayed
        current_dir   : "/",       // Initial current directory
        filter        : "",        // Initial file filter
        recursive     : false,     // Flag if subdirectory contents should be listed
        url_support   : true,      // Enable url support (this reads and writes url parameter)
        initial_tab   : 0,         // Initial tab to display 0 to 1

        enable_upload       : true, // Enable file upload controls
        enable_copy_items   : true, // Enable copy of items
        enable_sync_dir     : true, // Enable sync directory
        enable_create_dir   : true, // Enable creation of directories
        enable_rename_item  : true, // Enable rename of items
        enable_delete_items : true, // Enable deletion of items
    },

    // Create a new Rufs file browser.
    //
    newBrowser : function (container_id, config) {
        "use strict";

        // Create configuration

        var config = rufs.util.mergeObjects(rufs.browser.DEFAULT_CONFIG,
            config !== undefined ? config : {}),
            browser, mappings;

        // Support url parameters

        if (config.url_support) {
            var url_params = rufs.getURLParams()
            rufs.util.oValBool(url_params, ["recursive", "url_support", "enable_upload"]);
            config = rufs.util.mergeObjects(config, url_params)
        }

        // Ensure we have a main container

        var container = rufs.util.$(container_id);

        if (container === null) {
            throw("Cannot find root element: " + container_id);
        }

        rufs.util.ensureClassName(container, "rufs-main");

        // Create the base elements and display controller

        rufs.browser._constructBaseElements(container, config);

        browser = new rufs.RufsBrowser(config,
            container,
            rufs.util.find(container, "rufs-tree-switch"),
            rufs.util.find(container, "rufs-clipboard"),
            rufs.util.find(container, "rufs-current-path"),

            rufs.util.find(container, "rufs-dropdown-button"),
            rufs.util.find(container, "rufs-dropdown"),

            rufs.util.find(container, "rufs-dir-content"),

            rufs.util.find(container, "rufs-filter"),
            rufs.util.find(container, "rufs-select-all"),
            rufs.util.find(container, "rufs-select-none"),
            rufs.util.find(container, "rufs-select-invert"),

            rufs.util.find(container, "rufs-tabbed-area-error"),
            rufs.util.find(container, "rufs-zip-form"),
            rufs.util.find(container, "rufs-spinner"),
            rufs.util.find(container, "rufs-spinner-text"));

        mappings = new rufs.RufsMappings(config,
            container,
            rufs.util.find(container, "rufs-branches"),
            rufs.util.find(container, "rufs-mappings"));

        // Attach the browser element to the dom element

        container._rufs_browser = browser;
        container._rufs_config  = config;

        // Init the tabbing

        rufs.tabbing.init(container, config);

        if (config.enable_upload) {

            // Attach upload events

            rufs.ddfu.addEvents(container);
        }

        //  Get tree specification and mapping.

        rufs.util.api("admin/?refresh="+config.tree, "GET", {}, function (response, http) {
            var treeName = config.tree,
                treeSpec = response[treeName];

            try {
                if (treeSpec === undefined) {
                    throw("Unknown tree: " + config.tree);
                }
                var tree = new rufs.Tree(treeName, treeSpec);
                
                browser.setTree(tree);
                mappings.setTree(tree);

            } catch(e) {
                console.log(e);
                browser.showError(e);
            }
        }, browser.showError.bind(browser));
    },

    // Construct all HTML base elements inside a given div.
    //
    _constructBaseElements : function (container, config) {
        "use strict";

        // Tabbed area at the bottom

        var tabs = rufs.util.create("div", {
                "class" : "rufs-tabbed-area-tabs"
            }),
            filter = rufs.util.create("input", { "class" : "rufs-filter", "placeholder" : "glob filter" });

        // Add the tab contents

        rufs.util.insert(tabs, rufs.util.insertAll(
            rufs.util.create("div", { "class" : "rufs-tabbed-area-tab-content rufs-tabc-browser" }),
            [
                rufs.util.insertAll(rufs.util.create("h2"), [
                    rufs.util.createText(config.tree),
                    rufs.util.create("div", { "class" : "rufs-spinner", "style" : "display:none" }),
                    rufs.util.create("span", { "class" : "rufs-spinner-text", "style" : "display:none" }),
                    rufs.util.create("span", { "class" : "rufs-clipboard" }),
                ]),
                rufs.util.insertAll(rufs.util.create("div", { "class" : "rufs-tools" }), [
                    rufs.util.insert(rufs.util.create("button", { "class" : "rufs-tree-switch" }),
                        rufs.util.createText(config.recursive ? "Tree" : "Dir")),
                    rufs.util.create("input", { "class" : "rufs-current-path" }),
                    rufs.util.insertAll(rufs.util.create("div", { "class" : "rufs-dropdown-container" }), [
                        rufs.util.insert(rufs.util.create("button", { "class" : "rufs-dropdown-button" }),
                            rufs.util.createText("...")),
                        rufs.util.create("div", { "class" : "rufs-dropdown", "style" : "display:none" }),
                    ]),
                ]),
                rufs.util.create("table", { "class" : "rufs-dir-content" }),
                filter,
                rufs.util.insert(rufs.util.create("button", { "class" : "rufs-select-button rufs-select-all" }),
                    rufs.util.createText("All")),
                rufs.util.insert(rufs.util.create("button", { "class" : "rufs-select-button rufs-select-none" }),
                    rufs.util.createText("None")),
                rufs.util.insert(rufs.util.create("button", { "class" : "rufs-select-button rufs-select-invert" }),
                    rufs.util.createText("Invert"))
            ]));

        rufs.util.insert(tabs, rufs.util.insertAll(
            rufs.util.create("div", { "class" : "rufs-tabbed-area-tab-content rufs-tabc-mappings" }),
            [
                rufs.util.insert(rufs.util.create("h2"), rufs.util.createText("Known branches: " + config.tree)),
                rufs.util.create("table", { "class" : "rufs-branches" }),
                rufs.util.insert(rufs.util.create("h2"), rufs.util.createText("Mappings: " + config.tree)),
                rufs.util.create("table", { "class" : "rufs-mappings" }),
            ]));

        // Add an area to report errors

        rufs.util.insert(tabs, rufs.util.insert(rufs.util.create("div",
            { "class" : "rufs-tabbed-area-error",
              "style" : "display:none"}),
                rufs.util.create("div", {
                    "class" : "rufs-error" })));

        // Add the tab buttons

        rufs.util.insert(tabs, rufs.util.insertAll(
            rufs.util.create("div", { "class" : "rufs-buttons" }),
            [
                rufs.util.insert(rufs.util.create("button", {
                    "class" : "rufs-tabbed-area-tab rufs-tab-browser",
                    "title" : "Browser"
                }), rufs.util.createText("Browser")),

                rufs.util.insert(rufs.util.create("button", {
                    "class" : "rufs-tabbed-area-tab rufs-tab-mappings",
                    "title" : "Browser mappings"
                }), rufs.util.createText("Mappings"))
            ]));

        rufs.util.insert(container, tabs);

        // Create a hidden form

        rufs.util.insert(container, rufs.util.create("form", {
            "class"  : "rufs-zip-form",
            "method" : "POST",
            "action" : rufs.util.API_PATH + "/zip/" + config.tree
        }));

        // Set initial values

        filter.value = config.filter;
    }
};


// RufsBrowser controls the Rufs browser display
//
rufs.RufsBrowser = rufs.Class.create({

    // Create a new browser object.
    //
    init : function (config, container, tree_switch, clipboard, cd_input,
                     dd_button, dd_container, file_table, filter_input, 
                     selectAll, selectNone, selectInvert, errorElement,
                     zip_form, spinner, spinnerText) {
        "use strict";

        // Set object attributes

        this._container    = container;
        this._tree_switch  = tree_switch;
        this._clipboard    = clipboard;
        this._cd_input     = cd_input;
        this._dd_button    = dd_button;
        this._dd_container = dd_container;
        this._file_table   = file_table;
        this._filter_input = filter_input;
        this._selectAll    = selectAll;
        this._selectNone   = selectNone;
        this._selectInvert = selectInvert;
        this._errorElement = errorElement;
        this._zip_form     = zip_form;
        this._spinner      = spinner;
        this._spinnerText  = spinnerText;

        // Set control switches

        this._enable_copy_items   = config.enable_copy_items
        this._enable_sync_dir     = config.enable_sync_dir
        this._enable_create_dir   = config.enable_create_dir
        this._enable_rename_item  = config.enable_rename_item
        this._enable_delete_items = config.enable_delete_items

        // Set properties

        this._recursive = config.recursive;
        this._filter = config.filter;
        this._url_support = config.url_support;

        // Add listeners

        // Recursive listing button

        rufs.util.observe(this._tree_switch, "click", function () {
            this._recursive = !this._recursive;

            if (this._recursive) {
                this._tree_switch.innerHTML = "Tree";
            } else {
                this._tree_switch.innerHTML = "Dir";
            }

            if (this._url_support) {
                rufs.setURLParam("recursive", this._recursive);
            }

            this._updateFileListing();
        }.bind(this));

        // Current directory input

        rufs.util.observe(this._cd_input, "change", function () {
            var newdir = this._cd_input.value;

            if (newdir.indexOf("/", newdir.length-1) === -1) {
                newdir = newdir + "/";
            }

            this._updateCurrentDirectory(newdir);
            this._updateFileListing();
        }.bind(this));

        // Filter input

        rufs.util.observe(this._filter_input, "change", function () {
            this._filter = this._filter_input.value;

            if (this._url_support) {
                if (this._filter !== "") {
                    rufs.setURLParam("filter", this._filter);
                } else {
                    rufs.removeURLParam("filter");
                }
            }

            this._updateFileListing();
        }.bind(this));

        // Build up dropdown menu

        rufs.util.observe(this._dd_button, "click", function (e) {
            e.stopPropagation();

            if (this._dd_container.style.display === 'none') {
                this._updateDropdownMenu();
                rufs.util.show(this._dd_container);
            } else {
                rufs.util.hide(this._dd_container);
            }
        }.bind(this));

        rufs.util.observe(document, "click", function (e) {
            rufs.util.hide(this._dd_container);
        }.bind(this));

        rufs.util.observe(this._selectAll, "click", this.selectAll.bind(this));
        rufs.util.observe(this._selectNone, "click", this.selectNone.bind(this));
        rufs.util.observe(this._selectInvert, "click", this.selectInvert.bind(this));

        this._updateDropdownMenu();

        // Set the current directory

        // Note: this.cd should only be read. It should never be written
        //       to other than _updateCurrentDirectory.

        this._updateCurrentDirectory(config.current_dir);
    },

    _updateDropdownMenu : function () {
        "use strict";

        this._dd_container.innerHTML = "";

        var dd_actions = [
            [ "Zip selection", this._createZip ],
        ];

        if (this._enable_copy_items) {
            var copySelection = rufs.util.find(this._clipboard, "copy-selection");

            dd_actions.push([ "Copy selection", this._copyItems ]);

            if (copySelection !== undefined) {
                dd_actions.push([ "Paste items", this._pasteItems ]);
            }
        }
        if (this._enable_sync_dir) {
            dd_actions.push([ "Sync directories", this._syncDirs ]);
        }
        if (this._enable_create_dir) {
            dd_actions.push([ "Create directory", this._createDir ]);
        }
        if (this._enable_rename_item) {
            dd_actions.push([ "Rename item", this._renameItem ]);
        }
        if (this._enable_delete_items) {
            dd_actions.push([ "Delete selection", this._deleteSelection ]);
        }

        rufs.util.iter(dd_actions, function (i, item) {
            var button = rufs.util.create("button");

            if (item[1] !== undefined) {
                rufs.util.observe(button, "click", item[1].bind(this));
            }

            rufs.util.insert(this._dd_container,
                rufs.util.insert(button,
                    rufs.util.createText(item[0])));
        }.bind(this));
    },

    // Refresh the current view
    //
    refresh : function () {
        "use strict";

        this._updateFileListing();
    },

    // Return a  list of all selected files (full path)
    //
    selectedFiles : function(all) {
        "use strict";
        var selection = [],
            idClass = "rufs-file-item";

        if (all) {
            idClass = "rufs-item";
        }

        rufs.util.iter(rufs.util.findAll(this._file_table, idClass),
            function (i, item) {
                if (item.checked) {
                    selection.push(item.getAttribute("data-file-path"));
                }
            });

        return selection;
    },

    // Select all items
    //
    selectAll : function() {
        "use strict";

        rufs.util.iter(rufs.util.findAll(this._file_table, "rufs-item"),
            function (i, item) {
                item.checked = true;
            });
    },

    // Deselect all items
    //
    selectNone : function() {
        "use strict";

        rufs.util.iter(rufs.util.findAll(this._file_table, "rufs-item"),
            function (i, item) {
                item.checked = false;
            });
    },

    // Invert current selection
    //
    selectInvert : function() {
        "use strict";

        rufs.util.iter(rufs.util.findAll(this._file_table, "rufs-item"),
            function (i, item) {
                item.checked = !item.checked;
            });
    },

    // Initialise the browser with a new tree object.
    //
    setTree : function (tree) {
        "use strict";

        this.tree = tree;

        this._updateFileListing();
    },

    _updateCurrentDirectory : function (newdir) {
        "use strict";

        if (!newdir) {
            throw("No new current directory specified");
        }

        if (this._url_support) {
            rufs.setURLParam("current_dir", newdir);
        }

        this.cd = newdir;
        this._cd_input.value = newdir;
        this._container.setAttribute("data-upload-path", this.cd);
    },

    _updateFileListing : function () {
        "use strict";

        this._file_table.innerHTML = "";

        if (!this.tree) {
            this.showError("No tree definition was loaded");
            return;
        }

        // Show spinner

        this.showSpinner();

        var onUpAdded = false;

        var list = this.tree.dir(this.cd, this._filter, this._recursive, false, function (dir, files) {
            var tr = rufs.util.create("tr", {
                    "class" : "dir-item"
                }),
                reldir = dir.substring(this.cd.length);

            // Hide spinner

            this.hideAllSpinner();

            // Add "one-up" button

            if (this.cd !== "/" && !onUpAdded) {
                onUpAdded = true; // The "one-up" should only be added once

                rufs.util.insert(this._file_table,
                    rufs.util.insertAll(
                        tr, [
                            rufs.util.insert(rufs.util.create("td"), rufs.util.createText("")),
                            rufs.util.insert(rufs.util.create("td"), rufs.util.create("div", {
                                "class" : "rufs-icon rufs-icon-folder"
                            })),
                            rufs.util.insert(rufs.util.create("td"), rufs.util.createText("..")),
                            rufs.util.insert(rufs.util.create("td"), rufs.util.createText(""))
                        ]));

                rufs.util.observe(tr, "click", function () {
                    var path = this.cd.substring(1, this.cd.length-1).split('/'),
                        cd;

                    path.pop();
                    cd = "/";

                    if (path.length > 0) {
                        cd += path.join("/") + "/"
                    }

                    this._updateCurrentDirectory(cd);
                    this._updateFileListing();

                }.bind(this));
            }

            // Add folder contents

            rufs.util.iter(files, function (i, item) {
                var icon, label, checkbox;

                tr = rufs.util.create("tr", {
                    "class" : "dir-item"
                });

                // Determine icon and label

                if (item.isdir) {

                    if (this._recursive) {

                        // Do not show directories when doing recursive
                        // listings

                        return;
                    }

                    checkbox = rufs.util.create("input", {
                        "type" : "checkbox",
                        "class" : "rufs-item rufs-dir-item",
                        "data-file-path" : this.cd + item.name
                    });

                    icon = "rufs-icon-folder";
                    label = rufs.util.createText(reldir + item.name);

                } else {

                    checkbox = rufs.util.create("input", {
                        "type" : "checkbox",
                        "class" : "rufs-item rufs-file-item",
                        "data-file-path" : this.cd + item.name
                    });

                    icon = "rufs-icon-new-document";
                    label = rufs.util.insert(
                        rufs.util.create("a", {
                            "href" : rufs.util.fileURL(this.tree.name, this.cd + reldir + item.name)
                        }),
                        rufs.util.createText(reldir + item.name)
                    );
                }

                // Write out the table row

                rufs.util.insert(this._file_table,
                    rufs.util.insertAll(
                        tr, [
                            rufs.util.insert(rufs.util.create("td"), checkbox),
                            rufs.util.insert(rufs.util.create("td"), rufs.util.create("div", {
                                "class" : "rufs-icon " + icon
                            })),
                            rufs.util.insert(rufs.util.create("td"), label),
                            rufs.util.insert(rufs.util.create("td"),
                                rufs.util.createText(rufs.byteSizeString(item.size)))
                        ]));

                rufs.util.observe(checkbox, "click", function (e) {
                    e.stopPropagation();
                });

                rufs.util.observe(tr, "click", function () {

                    if (item.isdir) {

                        this._updateCurrentDirectory(this.cd + item.name + "/");
                        this._updateFileListing();
                    }

                }.bind(this));
            }.bind(this));

            if (files.length === 0) {

                // Display empty placeholder

                rufs.util.insert(this._file_table,
                    rufs.util.insert(
                        rufs.util.create("tr"), 
                            rufs.util.insert(
                                rufs.util.create("td"), 
                                    rufs.util.createText("Empty directory"))));
            }

        }.bind(this), this.showError.bind(this));
    },

    // Dropdown Actions
    // ================

    _copyItems : function () {
        "use strict";

        var files = this.selectedFiles(true);

        this._clipboard.innerHTML = "";

        rufs.util.insert(this._clipboard, rufs.util.insert(rufs.util.create("span", {
            "class" : "copy-selection",
            "data-items" : JSON.stringify(files),
            "title" : files.join("\n")
        }), rufs.util.createText("("+files.length+" item" + (files.length !== 1 ? "s" : "") + ")")));
    },

    _pasteItems : function () {
        "use strict";
        var copySelection = rufs.util.find(this._clipboard, "copy-selection"),
            items;

        if (!copySelection) {
            return;
        }

        items = JSON.parse(copySelection.getAttribute("data-items"));
        
        this.showSpinner();

        // Show spinner

        this.tree.copyItems(items, this.cd, function () {

            // Hide spinner

            this.hideAllSpinner();

            this._updateFileListing();
        }.bind(this), this.showError.bind(this));
    },

    _syncDirs : function () {
        "use strict";

    },

    _createDir : function () {
        "use strict";

        var name = prompt("Please enter the name of the directory:", "ParryHotter");

        if (!name) {
            console.log("ok");
            return
        }

        this.showSpinner();

        // Show spinner

        this.tree.createDir(this.cd, name, function () {

            // Hide spinner

            this.hideAllSpinner();

            this._updateFileListing();
        }.bind(this), this.showError.bind(this));
    },

    _renameItem : function () {
        "use strict";

        var files = this.selectedFiles(true);

        if (files.length === 0) {
            return
        } else if (files.length !== 1) {
            this.showError("This action can only rename a single file");
            return
        }

        var newName = prompt("Please enter the new name of the item");

        if (!newName) {
            console.log("ok");
            return
        }

        this.tree.rename(files[0], newName, function () {

            // Hide spinner

            this.hideAllSpinner();

            this._updateFileListing();
        }.bind(this), this.showError.bind(this));
    },

    _deleteSelection : function () {
        "use strict";

        var files = this.selectedFiles(true);

        if (files.length === 0) {
            return
        }

        if (confirm("Are you sure you want to delete " + files.length +
            " item" + (files.length !== 1 ? "s" : "") + "?")) {

            this.showSpinner();

            // Show spinner

            this.tree.delete(files, function () {

                // Hide spinner

                this.hideAllSpinner();

                this._updateFileListing();
            }.bind(this), this.showError.bind(this));
        }
    },

    _createZip : function () {
        "use strict";

        var files = this.selectedFiles();

        this._zip_form.innerHTML = "";

        rufs.util.insert(this._zip_form, rufs.util.create("input", {
            "type"  : "hidden",
            "name"  : "files",
            "value" : JSON.stringify(files)
        }));

        // This should come back with a file "save as" popup

        this._zip_form.submit();
    },

    // Messaging
    // =========

    // Show a loading spinner.
    //
    showSpinner : function () {
        "use strict";

        rufs.util.show(this._spinner);
    },

    // Show a loading spinner and some text.
    //
    showSpinnerText : function (text) {
        "use strict";

        rufs.util.show(this._spinner);
        rufs.util.show(this._spinnerText);
        this._spinnerText.innerHTML = rufs.util.esc(text);
    },

    // Hide loading spinner and text.
    //
    hideAllSpinner : function () {
        "use strict";

        rufs.util.hide(this._spinner);
        rufs.util.hide(this._spinnerText);
        this._spinnerText.innerHTML = "";
    },

    // Show an error in the browser.
    //
    showError : function (msg, errorID) {
        "use strict";

        var errorDisplay = rufs.util.find(this._errorElement, "rufs-error"),
            clearButton = rufs.util.insert(rufs.util.create('button'), rufs.util.createText('Clear'));

        if (errorID === undefined) {
            errorID = "Error";
        }

        errorDisplay.innerHTML = "";
        rufs.util.observe(clearButton, "click", this.clearError.bind(this, this._errorElement));

        rufs.util.insert(errorDisplay, rufs.util.createText(errorID));

        if (msg !== undefined) {
            rufs.util.insert(errorDisplay, rufs.util.createText(": " + msg));
        }

        rufs.util.insert(errorDisplay, rufs.util.createText(" "));
        rufs.util.insert(errorDisplay, clearButton);

        rufs.util.show(this._errorElement);
    },

    clearError : function () {
        "use strict";

        var errorDisplay = rufs.util.find(this._errorElement, "rufs-error")

        rufs.util.hide(this._errorElement);
        errorDisplay.innerHTML = "";
    }
});


// RufsMapping controls the Rufs mapping display
//
rufs.RufsMappings = rufs.Class.create({

    // Create a new browser object.
    //
    init : function (config, container, branches, mappings) {
        "use strict";

        // Set object attributes

        this._container = container;
        this._branches  = branches;
        this._mappings  = mappings;
    },
    
    // Initialise the browser with a new tree object.
    //
    setTree : function (tree) {
        "use strict";

        this.tree = tree;

        this._update();
    },
    
    _update : function () {
        "use strict";

        console.log(this.tree.mappings);

        // Iterate through branches

        rufs.util.insert(this._branches,
            rufs.util.insertAll(
                rufs.util.create("tr"), [
                    rufs.util.insert(rufs.util.create("td"), rufs.util.createText("Branch Name")),
                    rufs.util.insert(rufs.util.create("td"), rufs.util.createText("RPC Definition")),
                    rufs.util.insert(rufs.util.create("td"), rufs.util.createText("Fingerprint")),
                ]));        


        rufs.util.iter(this.tree.branches, function (i, item) {

            rufs.util.insert(this._branches,
                rufs.util.insertAll(
                    rufs.util.create("tr"), [
                        rufs.util.insert(rufs.util.create("td"), rufs.util.createText(item.branch)),
                        rufs.util.insert(rufs.util.create("td"), rufs.util.createText(item.rpc)),
                        rufs.util.insert(rufs.util.create("td"), rufs.util.createText(item.fingerprint)),
                    ]));        
        }.bind(this));

        rufs.util.insert(this._mappings,
            rufs.util.insertAll(
                rufs.util.create("tr"), [
                    rufs.util.insert(rufs.util.create("td"), rufs.util.createText("Branch Name")),
                    rufs.util.insert(rufs.util.create("td"), rufs.util.createText("Mapping directory")),
                    rufs.util.insert(rufs.util.create("td"), rufs.util.createText("Writeable")),
                ]));        

        rufs.util.iter(this.tree.mappings, function (i, item) {

            rufs.util.insert(this._mappings,
                rufs.util.insertAll(
                    rufs.util.create("tr"), [
                        rufs.util.insert(rufs.util.create("td"), rufs.util.createText(item.branch)),
                        rufs.util.insert(rufs.util.create("td"), rufs.util.createText(item.path)),
                        rufs.util.insert(rufs.util.create("td"), rufs.util.createText(item.writeable)),
                    ]));        
        }.bind(this));
    }
});


// Tree object modelling a Rufs tree
//
rufs.Tree = rufs.Class.create({

    // Create a new tree object.
    //
    init : function (name, spec) {
        "use strict";

        if (!spec.branches || !spec.tree) {
            throw("Invalid tree spec");
        }

        this.name = name;
        this.branches = spec.branches;
        this.mappings = spec.tree;
    },

    // Returns file listings of one or more directories via the given
    // callback.
    //
    dir : function (path, filter, recursive, checksums, callback, error_callback) {
        "use strict";

        rufs.util.api("/dir/" + this.name + "/" + path+
            "?recursive="+recursive+"&checksums="+checksums+"&glob="+filter,
            "GET", {}, function (response, http) {

            var dirs = rufs.util.oKeys(response);

            rufs.util.iter(dirs, function (i, item) {
                var files = response[item]

                if (!files || !files.length > 0) {
                    files = [];
                }

                if (item !== "/") {
                    item += "/";
                }

                callback(item, files);
            });
        }, error_callback)
    },

    // Copy items between directories.
    //
    copyItems : function (items, cd, callback, error_callback) {
        "use strict";

        rufs.util.api("/file/" + this.name + cd + name, "PUT", {
            "action" : "copy",
            "files" : items,
            "destination" : cd
        }, function (response, http) {
            callback();
        }, error_callback)
    },

    // Create a directory.
    //
    createDir : function (cd, name, callback, error_callback) {
        "use strict";

        rufs.util.api("/file/" + this.name + cd + name, "PUT", {
            "action" : "mkdir"
        }, function (response, http) {
            callback();
        }, error_callback)
    },

    // Rename an item.
    //
    rename : function (item, newName, callback, error_callback) {
        "use strict";

        rufs.util.api("/file/" + this.name + item, "PUT", {
            "action"  : "rename",
            "newname" : newName
        }, function (response, http) {
            callback();
        }, error_callback)
    },

    // Delete a list of items.
    //
    delete : function (items, callback, error_callback) {
        "use strict";

        rufs.util.api("/file/" + this.name, "DELETE", items,
            function (response, http) {
                callback();
            }, error_callback)
    }
});
